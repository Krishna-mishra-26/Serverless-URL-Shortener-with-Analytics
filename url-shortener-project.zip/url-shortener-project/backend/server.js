const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');
const cors = require('cors');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI;
app.use(cors());

console.log("MONGO_URI:", MONGO_URI);

mongoose.connect(MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error(err));

app.use(express.json());

// Serve static frontend files from client folder
app.use(express.static(path.join(__dirname, '..', 'client')));

// Import the shortID routes
const shortUrlRoutes = require('./routes/api');

// API routes for /api endpoints
app.use('/api', shortUrlRoutes);

// Special route for analytics.html
app.get('/analytics.html', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'client', 'analytics.html'));
});

// We need to mount the API routes directly at the root level for shortId handling
app.use('/', shortUrlRoutes);

// Ensure API routes return JSON for invalid endpoints
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'API route not found' });
});

// Serve index.html for root and other non-API routes
// But make sure this doesn't interfere with the shortID routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'client', 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
