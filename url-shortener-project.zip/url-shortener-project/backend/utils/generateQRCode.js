const QRCode = require('qrcode');

async function generateQRCode(url) {
  try {
    return await QRCode.toDataURL(url);
  } catch (error) {
    console.error('QR Code Generation Failed:', error);
    return null;
  }
}

module.exports = generateQRCode;
